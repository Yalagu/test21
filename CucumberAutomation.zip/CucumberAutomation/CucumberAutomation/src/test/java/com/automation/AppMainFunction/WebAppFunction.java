package com.automation.AppMainFunction;

import com.automation.WebCommonFunction.DriverUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

public class WebAppFunction extends DriverUtils {

    @FindBy(xpath="//a[normalize-space()='LAUNCH']")
    public WebElement launchBtn;

    @FindBy(xpath="//div[@class='screener-tab']/following-sibling::span")
    public WebElement settingsBtn;


    @FindBy(xpath="//label[normalize-space()='Benchmark:']")
    public WebElement benchMarkText;
    @FindBy(xpath="//div[@class='animate__animated animate__fadeInDown']")
    public WebElement settingDropDownDrawer;

    @FindBy(xpath="//input[contains(@id,'products-multiselect')]")
    public WebElement benchMarkDropDown;

    @FindBy(xpath="//div[@class='loading'][@hidden]")
    public WebElement loadingIconDisable;


    @FindBy(xpath="//div[@class='k-list-content k-list-scroller']//ul")
    public WebElement orgDropDownDrawer;

    @FindBy(xpath="//label[normalize-space()='Origination:']/following-sibling::span//span[@class='k-input-value-text' and normalize-space()='Select']")
    public WebElement originationDropDown;

    @FindBy(xpath="//label[normalize-space()='Portfolio Selection:']/following-sibling::span//span[@class='k-input-value-text' and normalize-space()='Select']")
    public WebElement portfolioDropDown;


    WebElement webElement=null;


    private static final Logger logger = LoggerFactory.getLogger(WebAppFunction.class);
    public  void  setUrl(){
        String appUrl=getValueFromProperitesFile("MainAppUrl");
        driver.get(String.valueOf(appUrl));
        logger.info("Launched url:"+appUrl);
    }
    public void clickOnSettingBtn(){
        waitForElementToBePresent(50,settingsBtn);
        click(settingsBtn);
        waitForElementToBePresent(100,benchMarkText);
        isElementDisplayed(settingDropDownDrawer);
        System.out.println("no1");
    }

    public void selectOptionFromBenchMark(String selectValue) throws Exception {
        waitForElementToBePresent(50,benchMarkDropDown);
        waitStatement("3");
        click(benchMarkDropDown);
//        setValueStaleElement(benchMarkDropDown,selectValue);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }
    public void waitStatement(String waitTime){
       try{
           Thread.sleep(1000*(Integer.valueOf(waitTime)));
       }catch (Exception e){

       }
    }
    public void selectOptionFromOrganization(String selectValue){
        waitForElementToBePresent(50,originationDropDown);
        click(originationDropDown);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        WebElement webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }

    public void selectPortofilioFromOrganization(String selectValue){
        waitForElementToBePresent(50,portfolioDropDown);
        click(portfolioDropDown);
        waitForElementToBePresent(50,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+selectValue+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+selectValue+"']"));
        click(webElement);
    }

    public void clickBtn(String btnText){
        waitForElementToBePresent(50,"xpath","//button/span[normalize-space()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//button/span[normalize-space()='"+btnText+"']"));
        click(webElement);
    }

    public void clickBtnTilt(String btnText){
        waitForElementToBePresent(50,"xpath","//span[normalize-space()='"+btnText+"']/parent::button[@type='submit']");
        webElement=driver.findElement(By.xpath("//span[normalize-space()='"+btnText+"']/parent::button[@type='submit']"));
        click(webElement);
    }

    public void loadingIconDisablePosition(){
        waitForElementToBePresent(500,loadingIconDisable);
        logger.info("loading completed..");

    }
    public void waitingForTextTab(String btnText){
        waitForElementToBePresent(200,"xpath","//ul//div[text()='"+btnText+"']");

    }

    public void waitingTitleHeader(String titleHeaderName){
        waitForElementToBePresent(200,"xpath"," //div[@class='title-header' and text()='"+titleHeaderName+"']|//label[text()='"+titleHeaderName+"']");

    }

    public void navigateToSideTap(String btnText){
        waitForElementToBePresent(200,"xpath","//ul//div[text()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//ul//div[text()='"+btnText+"']"));
        click(webElement);
    }

    public void navigateScreenerTap(String btnText){
        waitForElementToBePresent(200,"xpath","//div[@class='screener-tab']//h5[text()='"+btnText+"']");
        webElement=driver.findElement(By.xpath("//div[@class='screener-tab']//h5[text()='"+btnText+"']"));
        click(webElement);
    }

    public void updateInMainHeaderInput(String inputBoxName,String value){
        waitForElementToBePresent(50,"xpath","//label[text()='"+inputBoxName+"']/following-sibling::div//input");
        WebElement webElement=driver.findElement(By.xpath("//label[text()='"+inputBoxName+"']/following-sibling::div//input"));
        click(webElement);
        waitForElementToBePresent(100,orgDropDownDrawer);
        waitForElementToBePresent(50,"xpath","//li[@role='option']//span[normalize-space()='"+value+"']");
        webElement=driver.findElement(By.xpath("//li[@role='option']//span[normalize-space()='"+value+"']"));
        click(webElement);
    }

    public void updateTiltBoxInput(String inputBoxName,String value){
        String xpath="//label[text()='"+inputBoxName+"']/../following-sibling::div[contains(@class,'tilttext')]//input";
        waitForElementToBePresent(50,"xpath",xpath);
        WebElement webElement=driver.findElement(By.xpath(xpath));
        webElement.clear();
        setValueStaleElement(webElement,value);
    }

    public void clickOnMainHeaderInput(String inputBoxName){
        waitForElementToBePresent(50,"xpath","//label[text()='"+inputBoxName+"']/following-sibling::div//input");
        WebElement webElement=driver.findElement(By.xpath("//label[text()='"+inputBoxName+"']/following-sibling::div//input"));
        click(webElement);
        waitForElementToBePresent(100,orgDropDownDrawer);
    }

    public void verifyGraphXaxisYAxis(String xaxisName,String yAxisName){
        Assert.assertEquals(isElementDisplayed(driver.findElement(By.xpath("//*[normalize-space()='"+xaxisName+"' and @text-anchor='start']"))),true,"Xaxis name not matching");
        Assert.assertEquals(isElementDisplayed(driver.findElement(By.xpath("//*[@class='highcharts-axis-title' and text()='"+yAxisName+"']"))),true,"Yaxis name not matching");
    }



}
