package com.automation.stepdefs;

import com.automation.MobileWebMainFunction.BaseClass;
import com.automation.WebCommonFunction.DriverUtils;
import io.appium.java_client.AppiumDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;
import java.io.IOException;
import java.util.Collection;



public class CommonDef {

    public static Scenario currentScenario;
    public static String scenarioTag = "";
    public static String scenarioName = "";

    @BeforeSuite
    public void beforeSuite() throws IOException {
      //need to implement
    }

    @Before
    public void initialise(Scenario scenario){
        currentScenario = scenario;
        Collection<String> tags = scenario.getSourceTagNames();
        scenario.write("Current Date and Time in UTC format  :=> Today");
        scenarioTag = scenario.getSourceTagNames().toString();
        scenarioName = scenario.getName();
    }
    @After
    public void tearDown(Scenario scenario) {
        try {
            String screenshotName = scenario.getName().replaceAll("", "_");
            if (scenario.isFailed()) {
                TakesScreenshot ts = (TakesScreenshot) BaseClass.driver;
                byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "img/png", screenshotName);
                if (scenario.isFailed()) {
                    scenario.embed(screenshot, "image/png");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        BaseClass.driver.quit();
    }

    @AfterSuite
    public void afterSuite() {
      //need to implement
    }
}
